plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "ir.hamoongard.farhanglookup"
    compileSdk = 35
    defaultConfig {
        applicationId = "ir.hamoongard.farhanglookup"
        minSdk = 23
        targetSdk = 35
    versionCode = 6
    versionName = "4.2"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
}


kotlin {
    jvmToolchain(17)
}
