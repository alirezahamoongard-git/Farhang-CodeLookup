<?php
declare(strict_types=1);
require_once __DIR__ . '/common.php';
be_method('GET');
try {
  $u = be_auth($pdo);
  if ($u['role'] !== 'school_admin') be_json(403, ['ok'=>false,'error'=>'admin_only']);
  $schoolId = (int)$u['school_id'];
  $counts = [];
  foreach ([
    'classes' => "SELECT COUNT(*) FROM be_classes WHERE school_id=? AND status='active'",
    'students' => "SELECT COUNT(*) FROM be_students WHERE school_id=? AND status='active'",
    'scorers' => "SELECT COUNT(*) FROM be_scorers WHERE school_id=? AND is_active=1",
    'score_codes' => "SELECT COUNT(*) FROM be_score_codes WHERE school_id=? AND is_active=1",
    'users' => "SELECT COUNT(*) FROM be_users WHERE school_id=? AND is_active=1",
    'transactions' => "SELECT COUNT(*) FROM be_score_transactions WHERE school_id=? AND status='accepted'",
  ] as $key=>$sql) {
    $q=$pdo->prepare($sql); $q->execute([$schoolId]); $counts[$key]=(int)$q->fetchColumn();
  }
  $q=$pdo->prepare("SELECT id,class_code,class_name,grade_level FROM be_classes WHERE school_id=? AND status='active' ORDER BY grade_level,class_code");
  $q->execute([$schoolId]); $classes=$q->fetchAll(PDO::FETCH_ASSOC);
  $q=$pdo->prepare("SELECT id,import_type,row_count,success_count,error_count,status,original_filename,created_at FROM be_import_batches WHERE school_id=? ORDER BY id DESC LIMIT 10");
  $q->execute([$schoolId]); $imports=$q->fetchAll(PDO::FETCH_ASSOC);
  be_json(200,['ok'=>true,'school'=>['school_id'=>$schoolId,'user'=>$u['full_name']],'counts'=>$counts,'classes'=>$classes,'recent_imports'=>$imports]);
} catch (Throwable $e) { error_log('BankEmtiaz admin summary failed: '.get_class($e)); be_json(503,['ok'=>false,'error'=>'service_unavailable']); }
