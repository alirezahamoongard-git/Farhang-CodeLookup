<?php
// Reuse the existing production DB connector; do not duplicate credentials here.
$connector = dirname(__DIR__, 2) . '/api/db.php';
if (!is_file($connector)) { http_response_code(503); header('Content-Type: application/json; charset=utf-8'); echo json_encode(['ok'=>false,'error'=>'database_connector_not_found']); exit; }
require_once $connector;
if (!isset($pdo) || !$pdo instanceof PDO) { http_response_code(503); header('Content-Type: application/json; charset=utf-8'); echo json_encode(['ok'=>false,'error'=>'database_unavailable']); exit; }
