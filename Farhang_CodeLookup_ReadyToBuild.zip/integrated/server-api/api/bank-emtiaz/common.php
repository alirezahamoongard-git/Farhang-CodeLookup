<?php
declare(strict_types=1);
require_once __DIR__ . '/db.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, max-age=0');
header('X-Content-Type-Options: nosniff');
function be_json(int $status, array $payload): never { http_response_code($status); echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); exit; }
function be_body(): array { $raw=file_get_contents('php://input'); $d=json_decode($raw ?: '[]', true); if (!is_array($d)) be_json(400,['ok'=>false,'error'=>'invalid_json']); return $d; }
function be_method(string $method): void { if (($_SERVER['REQUEST_METHOD'] ?? '') !== $method) { header('Allow: '.$method); be_json(405,['ok'=>false,'error'=>'method_not_allowed']); } }
function be_uuid(string $v): bool { return (bool)preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i',$v); }
function be_auth(PDO $pdo): array {
  $h=(string)($_SERVER['HTTP_AUTHORIZATION'] ?? '');
  if (!preg_match('/^Bearer\s+([A-Za-z0-9_-]{40,160})$/i',$h,$m)) be_json(401,['ok'=>false,'error'=>'authentication_required']);
  $hash=hash('sha256',$m[1]);
  $q=$pdo->prepare("SELECT u.id id,u.school_id,u.username,u.full_name,u.role,u.class_id,s.status school_status,l.status license_status,l.starts_at,l.expires_at,t.id token_id FROM be_api_tokens t JOIN be_users u ON u.id=t.user_id JOIN be_schools s ON s.id=u.school_id JOIN licenses l ON l.id=s.license_id WHERE t.token_hash=? AND t.revoked_at IS NULL AND t.expires_at>NOW() AND u.is_active=1 LIMIT 1");
  $q->execute([$hash]); $u=$q->fetch(PDO::FETCH_ASSOC);
  if (!$u) be_json(401,['ok'=>false,'error'=>'invalid_or_expired_token']);
  if ($u['school_status']!=='active' || $u['license_status']!=='active' || strtotime((string)$u['starts_at'])>time() || ($u['expires_at'] && strtotime((string)$u['expires_at'])<time())) be_json(403,['ok'=>false,'error'=>'school_or_license_inactive']);
  $pdo->prepare('UPDATE be_api_tokens SET last_used_at=NOW() WHERE id=?')->execute([(int)$u['token_id']]);
  return $u;
}
function be_audit(PDO $pdo,int $schoolId,?int $userId,string $action,string $entityType='',?int $entityId=null,array $details=[]): void {
  try {$q=$pdo->prepare('INSERT INTO be_audit_logs (school_id,user_id,action,entity_type,entity_id,details,ip_address,created_at) VALUES (?,?,?,?,?,?,?,NOW())'); $q->execute([$schoolId?:null,$userId?:null,substr($action,0,100),$entityType?:null,$entityId,json_encode($details,JSON_UNESCAPED_UNICODE),substr((string)($_SERVER['REMOTE_ADDR']??''),0,45)]);} catch(Throwable $e) { error_log('BankEmtiaz audit write failed'); }
}
