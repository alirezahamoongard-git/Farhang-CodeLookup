<?php
declare(strict_types=1); require_once __DIR__.'/common.php'; be_method('GET');
try {$u=be_auth($pdo);$q=$pdo->prepare("SELECT id,score_code,description,category,points FROM be_score_codes WHERE school_id=? AND is_active=1 ORDER BY score_code");$q->execute([(int)$u['school_id']]);be_json(200,['ok'=>true,'score_codes'=>$q->fetchAll(PDO::FETCH_ASSOC)]);}catch(Throwable $e){error_log('BankEmtiaz score codes endpoint failed: '.get_class($e));be_json(503,['ok'=>false,'error'=>'service_unavailable']);}
