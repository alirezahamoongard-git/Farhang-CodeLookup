<?php
declare(strict_types=1);
require_once __DIR__ . '/common.php';
be_method('POST');
$u=be_auth($pdo);
if ($u['role'] !== 'school_admin') be_json(403,['ok'=>false,'error'=>'admin_only']);
$body=be_body();
$type=(string)($body['type']??'');
$rows=$body['rows']??null;
$filename=substr(trim((string)($body['filename']??'')),0,255);
if (!in_array($type,['students','scorers','score_codes','classes'],true)) be_json(400,['ok'=>false,'error'=>'invalid_import_type']);
if (!is_array($rows) || count($rows)<1 || count($rows)>5000) be_json(400,['ok'=>false,'error'=>'rows_must_contain_1_to_5000_items']);
$schoolId=(int)$u['school_id']; $userId=(int)$u['id']; $errors=[]; $success=0;
try {
  $pdo->beginTransaction();
  $batch=$pdo->prepare("INSERT INTO be_import_batches (school_id,imported_by,import_type,original_filename,row_count,status,created_at) VALUES (?,?,?,?,?,'started',NOW())");
  $batch->execute([$schoolId,$userId,$type,$filename?:null,count($rows)]); $batchId=(int)$pdo->lastInsertId();
  foreach ($rows as $idx=>$row) {
    $line=$idx+1;
    if (!is_array($row)) { $errors[]="row {$line}: invalid_row"; continue; }
    try {
      if ($type==='classes') {
        $code=trim((string)($row['class_code']??$row['code']??'')); $name=trim((string)($row['class_name']??$row['name']??'')); $grade=filter_var($row['grade_level']??$row['grade']??null,FILTER_VALIDATE_INT);
        if ($code===''||$name===''||$grade===false||$grade===null||$grade<1||$grade>12||strlen($code)>20||strlen($name)>100) throw new RuntimeException('required_fields_or_grade_invalid');
        $q=$pdo->prepare("INSERT INTO be_classes (school_id,class_code,class_name,grade_level,status) VALUES (?,?,?,?, 'active') ON DUPLICATE KEY UPDATE class_name=VALUES(class_name),grade_level=VALUES(grade_level),status='active'");
        $q->execute([$schoolId,$code,$name,$grade]);
      } elseif ($type==='students') {
        $code=trim((string)($row['student_code']??$row['code']??'')); $name=trim((string)($row['full_name']??$row['name']??'')); $classCode=trim((string)($row['class_code']??''));
        if ($code===''||$name===''||strlen($code)>50||strlen($name)>255) throw new RuntimeException('student_code_and_full_name_required');
        $classId=null;
        if ($classCode!=='') { $q=$pdo->prepare("SELECT id FROM be_classes WHERE school_id=? AND class_code=? AND status='active' LIMIT 1"); $q->execute([$schoolId,$classCode]); $v=$q->fetchColumn(); if (!$v) throw new RuntimeException('class_code_not_found'); $classId=(int)$v; }
        $q=$pdo->prepare("INSERT INTO be_students (school_id,class_id,student_code,full_name,status,imported_batch_id) VALUES (?,?,?,?, 'active',?) ON DUPLICATE KEY UPDATE class_id=VALUES(class_id),full_name=VALUES(full_name),status='active',imported_batch_id=VALUES(imported_batch_id)");
        $q->execute([$schoolId,$classId,$code,$name,$batchId]);
      } elseif ($type==='scorers') {
        $code=trim((string)($row['scorer_code']??$row['code']??'')); $name=trim((string)($row['full_name']??$row['name']??''));
        if ($code===''||$name===''||strlen($code)>50||strlen($name)>255) throw new RuntimeException('scorer_code_and_full_name_required');
        $q=$pdo->prepare("INSERT INTO be_scorers (school_id,scorer_code,full_name,is_active) VALUES (?,?,?,1) ON DUPLICATE KEY UPDATE full_name=VALUES(full_name),is_active=1");
        $q->execute([$schoolId,$code,$name]);
      } else {
        $code=filter_var($row['score_code']??$row['code']??null,FILTER_VALIDATE_INT); $desc=trim((string)($row['description']??$row['score_description']??$row['name']??'')); $cat=trim((string)($row['category']??'')); $points=filter_var($row['points']??$row['score']??null,FILTER_VALIDATE_INT);
        if ($code===false||$code===null||$code<1||$code>65535||$desc===''||strlen($desc)>500||!in_array($cat,['positive','negative','consumed'],true)||$points===false||$points===null||$points===0||$points < -32768||$points>32767) throw new RuntimeException('score_code_description_category_and_nonzero_points_required');
        if (($cat==='positive' && $points<0)||($cat!=='positive' && $points>0)) throw new RuntimeException('points_sign_does_not_match_category');
        $q=$pdo->prepare("INSERT INTO be_score_codes (school_id,score_code,description,category,points,is_active) VALUES (?,?,?,?,?,1) ON DUPLICATE KEY UPDATE description=VALUES(description),category=VALUES(category),points=VALUES(points),is_active=1");
        $q->execute([$schoolId,$code,$desc,$cat,$points]);
      }
      $success++;
    } catch (Throwable $rowError) { $errors[]="row {$line}: ".($rowError instanceof PDOException ? 'database_error' : $rowError->getMessage()); }
    if (count($errors)>=100) { $errors[]='additional_errors_truncated'; break; }
  }
  $status=($success===count($rows))?'completed':(($success>0)?'completed':'failed');
  $summary=$errors?implode("\n",array_slice($errors,0,100)):null;
  $q=$pdo->prepare("UPDATE be_import_batches SET success_count=?,error_count=?,status=?,error_summary=?,completed_at=NOW() WHERE id=? AND school_id=?");
  $q->execute([$success,count($errors),$status,$summary,$batchId,$schoolId]);
  be_audit($pdo,$schoolId,$userId,'data_import','import_batch',$batchId,['type'=>$type,'rows'=>count($rows),'success'=>$success,'errors'=>count($errors)]);
  $pdo->commit();
  be_json(200,['ok'=>true,'batch_id'=>$batchId,'type'=>$type,'row_count'=>count($rows),'success_count'=>$success,'error_count'=>count($errors),'errors'=>array_slice($errors,0,100)]);
} catch (Throwable $e) { if($pdo->inTransaction()) $pdo->rollBack(); error_log('BankEmtiaz import failed: '.get_class($e)); be_json(503,['ok'=>false,'error'=>'import_failed']); }
