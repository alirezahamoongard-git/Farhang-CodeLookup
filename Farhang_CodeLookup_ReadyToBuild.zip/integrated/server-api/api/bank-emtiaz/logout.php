<?php
declare(strict_types=1); require_once __DIR__.'/common.php'; be_method('POST');
$h=(string)($_SERVER['HTTP_AUTHORIZATION']??''); if(!preg_match('/^Bearer\s+([A-Za-z0-9_-]{40,160})$/i',$h,$m)) be_json(401,['ok'=>false,'error'=>'authentication_required']);
try {$hash=hash('sha256',$m[1]); $q=$pdo->prepare('UPDATE be_api_tokens SET revoked_at=NOW() WHERE token_hash=? AND revoked_at IS NULL'); $q->execute([$hash]); be_json(200,['ok'=>true]);} catch(Throwable $e){error_log('BankEmtiaz logout endpoint failed');be_json(503,['ok'=>false,'error'=>'service_unavailable']);}
