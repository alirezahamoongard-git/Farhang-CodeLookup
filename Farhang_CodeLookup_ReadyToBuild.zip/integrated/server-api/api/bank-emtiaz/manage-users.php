<?php
declare(strict_types=1);
require_once __DIR__ . '/common.php';
$u=be_auth($pdo);
if ($u['role'] !== 'school_admin') be_json(403,['ok'=>false,'error'=>'admin_only']);
$schoolId=(int)$u['school_id']; $actorId=(int)$u['id'];
if (($_SERVER['REQUEST_METHOD'] ?? '')==='GET') {
  try {
    $q=$pdo->prepare("SELECT id,username,full_name,role,class_id,is_active,last_login_at,created_at FROM be_users WHERE school_id=? ORDER BY is_active DESC, FIELD(role,'school_admin','deputy','teacher','student_representative'),full_name LIMIT 500");
    $q->execute([$schoolId]); $users=$q->fetchAll(PDO::FETCH_ASSOC);
    $q=$pdo->prepare("SELECT id,class_code,class_name,grade_level FROM be_classes WHERE school_id=? AND status='active' ORDER BY grade_level,class_code");
    $q->execute([$schoolId]); $classes=$q->fetchAll(PDO::FETCH_ASSOC);
    be_json(200,['ok'=>true,'users'=>$users,'classes'=>$classes]);
  } catch(Throwable $e) { error_log('BankEmtiaz manage users list failed'); be_json(503,['ok'=>false,'error'=>'service_unavailable']); }
}
be_method('POST'); $b=be_body(); $action=(string)($b['action']??'create');
try {
  if ($action==='create') {
    $username=trim((string)($b['username']??'')); $name=trim((string)($b['full_name']??'')); $password=(string)($b['password']??''); $role=(string)($b['role']??''); $classId=isset($b['class_id']) && $b['class_id']!=='' ? filter_var($b['class_id'],FILTER_VALIDATE_INT) : null;
    if (!preg_match('/^[A-Za-z0-9_.-]{3,100}$/',$username) || $name==='' || mb_strlen($name)>255 || strlen($password)<10 || strlen($password)>200 || !in_array($role,['deputy','teacher','student_representative'],true)) be_json(400,['ok'=>false,'error'=>'invalid_user_fields']);
    if (($role==='teacher'||$role==='student_representative') && (!$classId || $classId<1)) be_json(400,['ok'=>false,'error'=>'class_required']);
    if ($classId!==null) { $q=$pdo->prepare("SELECT id FROM be_classes WHERE id=? AND school_id=? AND status='active'"); $q->execute([$classId,$schoolId]); if(!$q->fetchColumn()) be_json(400,['ok'=>false,'error'=>'class_not_found']); }
    $q=$pdo->prepare('INSERT INTO be_users (school_id,username,password_hash,full_name,role,class_id,is_active,created_at,updated_at) VALUES (?,?,?,?,?,?,1,NOW(),NOW())');
    try {$q->execute([$schoolId,$username,password_hash($password,PASSWORD_DEFAULT),$name,$role,$classId]);} catch(PDOException $e) { if((string)$e->getCode()==='23000') be_json(409,['ok'=>false,'error'=>'username_exists']); throw $e; }
    $id=(int)$pdo->lastInsertId(); be_audit($pdo,$schoolId,$actorId,'user_created','be_user',$id,['username'=>$username,'role'=>$role,'class_id'=>$classId]); be_json(201,['ok'=>true,'user_id'=>$id]);
  }
  if ($action==='set_active') {
    $id=filter_var($b['user_id']??null,FILTER_VALIDATE_INT); $active=filter_var($b['is_active']??null,FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE);
    if (!$id || $active===null || $id===$actorId && !$active) be_json(400,['ok'=>false,'error'=>'invalid_user_state']);
    $pdo->beginTransaction();
    // Serialize account-state changes for this school to prevent concurrent requests
    // from disabling the last two active administrators at the same time.
    $schoolLock=$pdo->prepare('SELECT id FROM be_schools WHERE id=? FOR UPDATE'); $schoolLock->execute([$schoolId]);
    $q=$pdo->prepare('SELECT id,role,is_active FROM be_users WHERE id=? AND school_id=? FOR UPDATE'); $q->execute([$id,$schoolId]); $target=$q->fetch(PDO::FETCH_ASSOC); if(!$target){$pdo->rollBack();be_json(404,['ok'=>false,'error'=>'user_not_found']);}
    if (!$active && $target['role']==='school_admin' && (int)$target['is_active']===1) { $q=$pdo->prepare("SELECT COUNT(*) FROM be_users WHERE school_id=? AND role='school_admin' AND is_active=1"); $q->execute([$schoolId]); if((int)$q->fetchColumn()<=1){$pdo->rollBack();be_json(409,['ok'=>false,'error'=>'last_admin_cannot_be_disabled']);} }
    $q=$pdo->prepare('UPDATE be_users SET is_active=?,updated_at=NOW() WHERE id=? AND school_id=?'); $q->execute([$active?1:0,$id,$schoolId]); if(!$active)$pdo->prepare('UPDATE be_api_tokens SET revoked_at=NOW() WHERE user_id=? AND revoked_at IS NULL')->execute([$id]); $pdo->commit(); be_audit($pdo,$schoolId,$actorId,'user_active_changed','be_user',$id,['is_active'=>$active]); be_json(200,['ok'=>true,'user_id'=>$id,'is_active'=>$active]);
  }
  if ($action==='reset_password') {
    $id=filter_var($b['user_id']??null,FILTER_VALIDATE_INT); $password=(string)($b['password']??''); if(!$id||strlen($password)<10||strlen($password)>200)be_json(400,['ok'=>false,'error'=>'invalid_password']);
    $q=$pdo->prepare('UPDATE be_users SET password_hash=?,updated_at=NOW() WHERE id=? AND school_id=?'); $q->execute([password_hash($password,PASSWORD_DEFAULT),$id,$schoolId]); if(!$q->rowCount())be_json(404,['ok'=>false,'error'=>'user_not_found']); $pdo->prepare('UPDATE be_api_tokens SET revoked_at=NOW() WHERE user_id=? AND revoked_at IS NULL')->execute([$id]); be_audit($pdo,$schoolId,$actorId,'user_password_reset','be_user',$id); be_json(200,['ok'=>true,'user_id'=>$id]);
  }
  be_json(400,['ok'=>false,'error'=>'invalid_action']);
} catch(Throwable $e) { if($pdo->inTransaction())$pdo->rollBack(); error_log('BankEmtiaz manage users failed: '.get_class($e)); be_json(503,['ok'=>false,'error'=>'service_unavailable']); }
