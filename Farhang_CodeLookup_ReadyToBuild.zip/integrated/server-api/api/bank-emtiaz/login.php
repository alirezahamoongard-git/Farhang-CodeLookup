<?php
declare(strict_types=1); require_once __DIR__.'/common.php'; be_method('POST'); $in=be_body();
$username=trim((string)($in['username']??'')); $password=(string)($in['password']??''); $licenseKey=trim((string)($in['license_key']??''));
if ($username==='' || $password==='' || $licenseKey==='') be_json(400,['ok'=>false,'error'=>'username_password_license_required']);
if (strlen($username)>100 || strlen($password)>1024 || strlen($licenseKey)>80) be_json(400,['ok'=>false,'error'=>'input_too_long']);
try {
 $q=$pdo->prepare("SELECT u.id,u.school_id,u.username,u.password_hash,u.full_name,u.role,u.class_id,s.status school_status,l.status license_status,l.starts_at,l.expires_at FROM be_users u JOIN be_schools s ON s.id=u.school_id JOIN licenses l ON l.id=s.license_id WHERE u.username=? AND l.license_key=? AND u.is_active=1 LIMIT 1");
 $q->execute([$username,$licenseKey]); $u=$q->fetch(PDO::FETCH_ASSOC);
 if (!$u || !password_verify($password,(string)$u['password_hash'])) { usleep(250000); be_json(401,['ok'=>false,'error'=>'invalid_credentials']); }
 if ($u['school_status']!=='active' || $u['license_status']!=='active' || strtotime((string)$u['starts_at'])>time() || ($u['expires_at'] && strtotime((string)$u['expires_at'])<time())) be_json(403,['ok'=>false,'error'=>'school_or_license_inactive']);
 $token= rtrim(strtr(base64_encode(random_bytes(48)),'+/','-_'),'='); $hash=hash('sha256',$token); $expires=(new DateTimeImmutable('+30 days'))->format('Y-m-d H:i:s');
 $pdo->prepare('INSERT INTO be_api_tokens (user_id,token_hash,expires_at,created_at) VALUES (?,?,?,NOW())')->execute([(int)$u['id'],$hash,$expires]);
 $pdo->prepare('UPDATE be_users SET last_login_at=NOW() WHERE id=?')->execute([(int)$u['id']]); be_audit($pdo,(int)$u['school_id'],(int)$u['id'],'api_login','user',(int)$u['id']);
 be_json(200,['ok'=>true,'token'=>$token,'expires_at'=>$expires,'user'=>['id'=>(int)$u['id'],'school_id'=>(int)$u['school_id'],'username'=>$u['username'],'full_name'=>$u['full_name'],'role'=>$u['role'],'class_id'=>$u['class_id']===null?null:(int)$u['class_id']]]);
} catch(Throwable $e) { error_log('BankEmtiaz login endpoint failed: '.get_class($e)); be_json(503,['ok'=>false,'error'=>'service_unavailable']); }
