-- Additive migration for Bank Emtiaz API authentication.
-- Run only AFTER Phase 1 schema has been reviewed and installed.
-- This migration creates one new table and does not alter existing tables.
CREATE TABLE IF NOT EXISTS be_api_tokens (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id BIGINT UNSIGNED NOT NULL,
  token_hash CHAR(64) NOT NULL,
  expires_at DATETIME NOT NULL,
  last_used_at DATETIME NULL,
  revoked_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_be_api_token_hash (token_hash),
  KEY ix_be_api_token_user (user_id, expires_at, revoked_at),
  CONSTRAINT fk_be_api_tokens_user FOREIGN KEY (user_id) REFERENCES be_users(id)
    ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
