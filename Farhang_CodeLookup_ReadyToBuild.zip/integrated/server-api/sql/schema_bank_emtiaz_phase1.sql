-- Bank Emtiaz: Phase 1 schema
-- Review/import only after confirming the current database backup.
-- Does NOT alter or drop existing licenses, devices, activation_logs, admin_users,
-- or admin_audit_logs tables. All new tables use the be_ prefix.
-- Intended database: bimehamo_license
-- MySQL/MariaDB with InnoDB and utf8mb4.

CREATE TABLE IF NOT EXISTS be_schools (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  license_id BIGINT UNSIGNED NOT NULL,
  school_name VARCHAR(255) NOT NULL,
  school_code VARCHAR(50) NULL,
  status ENUM('active','suspended') NOT NULL DEFAULT 'active',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_be_schools_license (license_id),
  UNIQUE KEY uq_be_schools_code (school_code),
  CONSTRAINT fk_be_schools_license FOREIGN KEY (license_id) REFERENCES licenses(id)
    ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS be_classes (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  school_id BIGINT UNSIGNED NOT NULL,
  class_code VARCHAR(20) NOT NULL,
  class_name VARCHAR(100) NOT NULL,
  grade_level TINYINT UNSIGNED NOT NULL,
  status ENUM('active','archived') NOT NULL DEFAULT 'active',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_be_class_code (school_id, class_code),
  KEY ix_be_classes_school (school_id, status),
  CONSTRAINT fk_be_classes_school FOREIGN KEY (school_id) REFERENCES be_schools(id)
    ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS be_students (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  school_id BIGINT UNSIGNED NOT NULL,
  class_id BIGINT UNSIGNED NULL,
  student_code VARCHAR(50) NOT NULL,
  full_name VARCHAR(255) NOT NULL,
  status ENUM('active','inactive') NOT NULL DEFAULT 'active',
  imported_batch_id BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_be_student_code (school_id, student_code),
  KEY ix_be_students_class (school_id, class_id, status),
  CONSTRAINT fk_be_students_school FOREIGN KEY (school_id) REFERENCES be_schools(id)
    ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT fk_be_students_class FOREIGN KEY (class_id) REFERENCES be_classes(id)
    ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS be_users (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  school_id BIGINT UNSIGNED NOT NULL,
  username VARCHAR(100) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  full_name VARCHAR(255) NOT NULL,
  role ENUM('school_admin','deputy','teacher','student_representative') NOT NULL,
  class_id BIGINT UNSIGNED NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  last_login_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_be_user_name (school_id, username),
  KEY ix_be_users_role (school_id, role, is_active),
  CONSTRAINT fk_be_users_school FOREIGN KEY (school_id) REFERENCES be_schools(id)
    ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT fk_be_users_class FOREIGN KEY (class_id) REFERENCES be_classes(id)
    ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS be_scorers (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  school_id BIGINT UNSIGNED NOT NULL,
  scorer_code VARCHAR(50) NOT NULL,
  full_name VARCHAR(255) NOT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_be_scorer_code (school_id, scorer_code),
  CONSTRAINT fk_be_scorers_school FOREIGN KEY (school_id) REFERENCES be_schools(id)
    ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS be_score_codes (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  school_id BIGINT UNSIGNED NOT NULL,
  score_code SMALLINT UNSIGNED NOT NULL,
  description VARCHAR(500) NOT NULL,
  category ENUM('positive','negative','consumed') NOT NULL,
  points SMALLINT NOT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_be_score_code (school_id, score_code),
  CONSTRAINT fk_be_score_codes_school FOREIGN KEY (school_id) REFERENCES be_schools(id)
    ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS be_import_batches (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  school_id BIGINT UNSIGNED NOT NULL,
  imported_by BIGINT UNSIGNED NULL,
  import_type ENUM('students','scorers','score_codes','classes') NOT NULL,
  original_filename VARCHAR(255) NULL,
  row_count INT UNSIGNED NOT NULL DEFAULT 0,
  success_count INT UNSIGNED NOT NULL DEFAULT 0,
  error_count INT UNSIGNED NOT NULL DEFAULT 0,
  status ENUM('started','completed','failed') NOT NULL DEFAULT 'started',
  error_summary TEXT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  completed_at DATETIME NULL,
  PRIMARY KEY (id),
  KEY ix_be_import_batches_school (school_id, created_at),
  CONSTRAINT fk_be_import_batches_school FOREIGN KEY (school_id) REFERENCES be_schools(id)
    ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT fk_be_import_batches_user FOREIGN KEY (imported_by) REFERENCES be_users(id)
    ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS be_score_transactions (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  school_id BIGINT UNSIGNED NOT NULL,
  student_id BIGINT UNSIGNED NOT NULL,
  score_code_id BIGINT UNSIGNED NOT NULL,
  scorer_id BIGINT UNSIGNED NULL,
  entered_by BIGINT UNSIGNED NULL,
  points SMALLINT NOT NULL,
  request_id CHAR(36) NOT NULL,
  note VARCHAR(500) NULL,
  status ENUM('accepted','voided') NOT NULL DEFAULT 'accepted',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  voided_at DATETIME NULL,
  voided_by BIGINT UNSIGNED NULL,
  void_reason VARCHAR(500) NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_be_score_request (school_id, request_id),
  KEY ix_be_scores_student (school_id, student_id, status, created_at),
  KEY ix_be_scores_class_reporting (school_id, created_at, status),
  CONSTRAINT fk_be_scores_school FOREIGN KEY (school_id) REFERENCES be_schools(id)
    ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT fk_be_scores_student FOREIGN KEY (student_id) REFERENCES be_students(id)
    ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT fk_be_scores_code FOREIGN KEY (score_code_id) REFERENCES be_score_codes(id)
    ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT fk_be_scores_scorer FOREIGN KEY (scorer_id) REFERENCES be_scorers(id)
    ON UPDATE CASCADE ON DELETE SET NULL,
  CONSTRAINT fk_be_scores_entered_by FOREIGN KEY (entered_by) REFERENCES be_users(id)
    ON UPDATE CASCADE ON DELETE SET NULL,
  CONSTRAINT fk_be_scores_voided_by FOREIGN KEY (voided_by) REFERENCES be_users(id)
    ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS be_audit_logs (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  school_id BIGINT UNSIGNED NULL,
  user_id BIGINT UNSIGNED NULL,
  action VARCHAR(100) NOT NULL,
  entity_type VARCHAR(80) NULL,
  entity_id BIGINT UNSIGNED NULL,
  details JSON NULL,
  ip_address VARCHAR(45) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY ix_be_audit_school_time (school_id, created_at),
  CONSTRAINT fk_be_audit_school FOREIGN KEY (school_id) REFERENCES be_schools(id)
    ON UPDATE CASCADE ON DELETE SET NULL,
  CONSTRAINT fk_be_audit_user FOREIGN KEY (user_id) REFERENCES be_users(id)
    ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
