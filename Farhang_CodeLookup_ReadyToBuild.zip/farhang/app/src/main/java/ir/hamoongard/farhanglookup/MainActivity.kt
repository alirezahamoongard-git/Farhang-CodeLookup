package ir.hamoongard.farhanglookup

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.content.ContentValues
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.text.InputFilter
import android.text.InputType
import android.widget.*
import android.content.Intent
import android.util.Base64
import android.provider.Settings
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import java.util.zip.ZipInputStream
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory

class MainActivity : Activity() {
    private val PICK_STUDENTS = 1101
    private val PICK_SCORERS = 1102
    private val PICK_SCORES = 1103
    private var importKind = 0

    private lateinit var names: Map<String, String>
    private lateinit var scorers: Map<String, String>
    private lateinit var scoreDescriptions: Map<String, String>
    private val records = mutableListOf<ScoreRecord>()
    private var lastExportUri: Uri? = null

    private val licenseBaseUrl = "https://license.bimehamoon.ir/api"
    private val licensePrefs by lazy { getSharedPreferences("license", MODE_PRIVATE) }
    private val offlineGraceMs = 7L * 24L * 60L * 60L * 1000L

    data class ScoreRecord(
        val studentCode: String,
        val studentName: String,
        val scoreCode: String,
        val scorerCode: String,
        val score: String,
        val description: String,
        val dateTime: String
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        names = buildMap {
            DATA.trim().lines().forEach {
                val p = it.split("|", limit = 2)
                if (p.size == 2) put(p[0], p[1])
            }
        }
        scorers = loadMap("scorers")
        scoreDescriptions = loadMap("scoreDescriptions")
        loadDatabase()
        loadRecords()
        ensureLicenseThenStart()
    }

    private fun ensureLicenseThenStart() {
        val key = licensePrefs.getString("license_key", "")?.trim().orEmpty()
        if (key.isBlank()) {
            showActivationScreen()
            return
        }

        val lastCheck = licensePrefs.getLong("last_check", 0L)
        val expiry = licensePrefs.getLong("expiry", 0L)
        if (expiry > 0L && System.currentTimeMillis() > expiry) {
            showActivationScreen("مجوز این نسخه منقضی شده است. لطفاً مجوز معتبر وارد کنید.")
            return
        }

        Thread {
            val result = checkLicenseOnline(key)
            runOnUiThread {
                if (result.success && result.valid) {
                    saveLicenseResult(key, result)
                    buildScreen()
                } else if (!result.networkError && !result.valid) {
                    clearLicense()
                    showActivationScreen(result.message.ifBlank { "مجوز معتبر نیست یا غیرفعال شده است." })
                } else if (lastCheck > 0L && System.currentTimeMillis() - lastCheck <= offlineGraceMs && expiry > System.currentTimeMillis()) {
                    Toast.makeText(this, "اتصال به سرور برقرار نشد؛ برنامه در مهلت آفلاین مجاز اجرا می‌شود.", Toast.LENGTH_LONG).show()
                    buildScreen()
                } else {
                    showActivationScreen("برای بررسی مجوز، اتصال اینترنت را برقرار کنید و دوباره تلاش کنید.")
                }
            }
        }.start()
    }

    private data class LicenseResult(
        val success: Boolean,
        val valid: Boolean,
        val networkError: Boolean,
        val message: String = "",
        val school: String = "",
        val expiresAt: Long = 0L
    )

    private fun showActivationScreen(initialMessage: String = "") {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(28), dp(24), dp(28))
            setBackgroundColor(Color.rgb(244, 247, 251))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        val title = TextView(this).apply {
            text = "بانک امتیاز"
            textSize = 29f
            setTextColor(Color.rgb(13, 71, 161))
            gravity = Gravity.CENTER
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        root.addView(title, LinearLayout.LayoutParams(-1, dp(55)))

        val subtitle = TextView(this).apply {
            text = "فعال‌سازی نسخه کاربر"
            textSize = 19f
            setTextColor(Color.rgb(48, 59, 77))
            gravity = Gravity.CENTER
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        root.addView(subtitle, LinearLayout.LayoutParams(-1, dp(42)))

        val info = TextView(this).apply {
            text = "برای استفاده از برنامه، کد مجوزی را که از مدیر سامانه دریافت کرده‌اید وارد کنید."
            textSize = 14.5f
            setTextColor(Color.rgb(90, 100, 118))
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(8), dp(8), dp(16))
        }
        root.addView(info, LinearLayout.LayoutParams(-1, dp(70)))

        val keyInput = EditText(this).apply {
            hint = "کد مجوز را وارد کنید"
            textSize = 18f
            gravity = Gravity.CENTER
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            setSingleLine(true)
            setPadding(dp(14), 0, dp(14), 0)
            background = roundedStroke(Color.WHITE, Color.rgb(70, 120, 190), dp(14))
        }
        val savedKey = licensePrefs.getString("license_key", "").orEmpty()
        if (savedKey.isNotBlank()) keyInput.setText(savedKey)
        root.addView(keyInput, LinearLayout.LayoutParams(-1, dp(58)))

        val device = TextView(this).apply {
            text = "شناسه دستگاه: ${getDeviceId().take(12)}"
            textSize = 12.5f
            setTextColor(Color.rgb(115, 125, 140))
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(10))
        }
        root.addView(device, LinearLayout.LayoutParams(-1, dp(48)))

        val activate = Button(this).apply {
            text = "✓  فعال‌سازی برنامه"
            textSize = 17f
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(0, 137, 123), dp(15))
            isAllCaps = false
        }
        root.addView(activate, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(8) })

        val status = TextView(this).apply {
            text = initialMessage
            textSize = 14f
            setTextColor(Color.rgb(190, 55, 55))
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(12), dp(6), 0)
        }
        root.addView(status, LinearLayout.LayoutParams(-1, dp(70)))

        val producer = TextView(this).apply {
            text = "تولید کننده: علیرضا هامونگرد"
            textSize = 12.5f
            setTextColor(Color.rgb(102, 112, 133))
            gravity = Gravity.CENTER
        }
        root.addView(producer, LinearLayout.LayoutParams(-1, dp(40)))

        activate.setOnClickListener {
            val licenseKey = keyInput.text.toString().trim()
            if (licenseKey.isBlank()) {
                status.text = "لطفاً کد مجوز را وارد کنید."
                return@setOnClickListener
            }
            activate.isEnabled = false
            status.setTextColor(Color.rgb(70, 90, 110))
            status.text = "در حال بررسی مجوز با سرور..."
            Thread {
                val result = activateLicenseOnline(licenseKey)
                runOnUiThread {
                    activate.isEnabled = true
                    if (result.success && result.valid) {
                        saveLicenseResult(licenseKey, result)
                        Toast.makeText(this, "فعال‌سازی با موفقیت انجام شد.", Toast.LENGTH_LONG).show()
                        buildScreen()
                    } else {
                        status.setTextColor(Color.rgb(190, 55, 55))
                        status.text = result.message.ifBlank { "فعال‌سازی انجام نشد." }
                    }
                }
            }.start()
        }

        setContentView(root)
    }

    private fun getDeviceId(): String = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID)
        ?.takeIf { it.isNotBlank() } ?: "unknown-${Build.SERIAL ?: "device"}"

    private fun getDeviceName(): String = "${Build.MANUFACTURER} ${Build.MODEL}".trim()

    private fun postLicense(endpoint: String, licenseKey: String): LicenseResult {
        return try {
            val url = URL("$licenseBaseUrl/$endpoint")
            val connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 12000
                readTimeout = 12000
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                setRequestProperty("Accept", "application/json")
            }
            val body = JSONObject().apply {
                put("license_key", licenseKey)
                put("device_id", getDeviceId())
                put("device_name", getDeviceName())
            }.toString()
            connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..399) connection.inputStream else connection.errorStream
            val response = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            connection.disconnect()
            val json = JSONObject(response)
            val ok = json.optBoolean("ok", false)
            val valid = json.optBoolean("valid", ok)
            val message = json.optString("message", "")
            val school = json.optString("school", "")
            val expiryText = json.optString("expires_at", json.optString("expiry", ""))
            val expiresAt = parseServerDate(expiryText)
            LicenseResult(ok && code in 200..399, valid, false, message, school, expiresAt)
        } catch (e: Exception) {
            LicenseResult(false, false, true, e.message.orEmpty())
        }
    }

    private fun activateLicenseOnline(key: String): LicenseResult = postLicense("activate.php", key)
    private fun checkLicenseOnline(key: String): LicenseResult = postLicense("check.php", key)

    private fun parseServerDate(value: String): Long {
        if (value.isBlank()) return 0L
        value.toLongOrNull()?.let {
            return if (it < 100000000000L) it * 1000L else it
        }
        val formats = listOf("yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd'T'HH:mm:ssXXX", "yyyy-MM-dd'T'HH:mm:ssXXX")
        for (pattern in formats) {
            try {
                val d = java.text.SimpleDateFormat(pattern, Locale.US).parse(value)
                if (d != null) return d.time
            } catch (_: Exception) {}
        }
        return 0L
    }

    private fun saveLicenseResult(key: String, result: LicenseResult) {
        val editor = licensePrefs.edit()
            .putString("license_key", key)
            .putLong("last_check", System.currentTimeMillis())
        if (result.expiresAt > 0L) editor.putLong("expiry", result.expiresAt)
        if (result.school.isNotBlank()) editor.putString("school", result.school)
        editor.apply()
    }

    private fun clearLicense() {
        licensePrefs.edit().clear().apply()
    }

    private fun buildScreen() {
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(244, 247, 251)) }
        val bg = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(12), dp(10), dp(12), dp(16))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        scroll.addView(bg)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = rounded(Color.rgb(13, 71, 161), dp(22))
            isClickable = true
            setOnClickListener { changeSchoolName() }
        }
        val school = TextView(this).apply {
            text = getSchoolName()
            textSize = 24f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        val title = TextView(this).apply {
            text = "سامانه ثبت و مدیریت امتیاز دانش‌آموز"
            textSize = 16f
            setTextColor(Color.rgb(220, 235, 255))
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
        }
        val producer = TextView(this).apply {
            text = "تولید کننده: علیرضا هامونگرد"
            textSize = 12.5f
            setTextColor(Color.rgb(220, 235, 255))
            gravity = Gravity.CENTER
            setPadding(0, dp(7), 0, 0)
        }
        header.addView(school)
        header.addView(title)
        header.addView(producer)
        bg.addView(header, LinearLayout.LayoutParams(-1, dp(96)))

        val databaseButton = Button(this).apply {
            text = "📂  تغذیه اطلاعات اولیه از Excel"
            textSize = 15f
            setTextColor(Color.rgb(13, 71, 161))
            background = roundedStroke(Color.rgb(239, 246, 255), Color.rgb(21, 101, 192), dp(14))
            isAllCaps = false
        }
        bg.addView(databaseButton, LinearLayout.LayoutParams(-1, dp(42)).apply { topMargin = dp(5) })

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(6), dp(12), dp(8))
            background = rounded(Color.WHITE, dp(22))
        }
        bg.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        fun addLabel(text: String) {
            card.addView(TextView(this).apply {
                this.text = text
                textSize = 15.5f
                setTextColor(Color.rgb(48, 59, 77))
                gravity = Gravity.RIGHT
                setPadding(0, dp(3), 0, dp(3))
                setTypeface(null, android.graphics.Typeface.BOLD)
            })
        }

        fun edit(hint: String, size: Float = 18f, numeric: Boolean = false): EditText = EditText(this).apply {
            this.hint = hint
            textSize = size
            gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
            inputType = if (numeric) InputType.TYPE_CLASS_NUMBER else InputType.TYPE_CLASS_TEXT
            setSingleLine(true)
            setPadding(dp(16), 0, dp(16), 0)
            background = roundedStroke(Color.rgb(248, 250, 253), Color.rgb(70, 120, 190), dp(14))
        }

        fun infoBox(initial: String = "—"): TextView = TextView(this).apply {
            text = initial
            textSize = 17f
            setTextColor(Color.rgb(13, 71, 161))
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(Color.rgb(239, 246, 255), dp(14))
        }

        addLabel("کد شناسایی دانش‌آموز")
        val code = edit("کد شناسایی دانش‌آموز را وارد کنید", 20f, true)
        code.filters = arrayOf(InputFilter.LengthFilter(4))
        card.addView(code, LinearLayout.LayoutParams(-1, dp(54)))

        addLabel("نام و نام خانوادگی")
        val result = infoBox()
        card.addView(result, LinearLayout.LayoutParams(-1, dp(54)))

        addLabel("کد امتیاز")
        val scoreCode = edit("کد امتیاز را وارد کنید", 17f, true)
        card.addView(scoreCode, LinearLayout.LayoutParams(-1, dp(54)))

        addLabel("شرح امتیاز")
        val scoreDescription = infoBox()
        card.addView(scoreDescription, LinearLayout.LayoutParams(-1, dp(54)))

        addLabel("کد امتیازدهنده")
        val scorerCode = edit("کد امتیازدهنده را وارد کنید", 17f, true)
        card.addView(scorerCode, LinearLayout.LayoutParams(-1, dp(54)))

        addLabel("نام امتیازدهنده")
        val scorerName = infoBox()
        card.addView(scorerName, LinearLayout.LayoutParams(-1, dp(54)))

        addLabel("میزان امتیاز")
        val score = edit("مثلاً 10", 18f, true)
        card.addView(score, LinearLayout.LayoutParams(-1, dp(54)))

        val register = Button(this).apply {
            text = "✓  ثبت امتیاز"
            textSize = 17f
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(0, 137, 123), dp(15))
            isAllCaps = false
        }
        card.addView(register, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(7) })

        val export = Button(this).apply {
            text = "📤  خروجی اکسل"
            textSize = 15f
            setTextColor(Color.rgb(13, 71, 161))
            background = roundedStroke(Color.rgb(239, 246, 255), Color.rgb(21, 101, 192), dp(14))
            isAllCaps = false
        }
        card.addView(export, LinearLayout.LayoutParams(-1, dp(42)).apply { topMargin = dp(4) })

        val count = TextView(this).apply {
            text = "تعداد امتیازهای ثبت‌شده: ${records.size}"
            textSize = 13.5f
            setTextColor(Color.rgb(102, 112, 133))
            gravity = Gravity.CENTER
            setPadding(0, dp(2), 0, 0)
        }
        card.addView(count)

        fun lookupStudent() {
            val raw = code.text.toString().filter { it.isDigit() }
            if (raw.length != 4) result.text = "کد شناسایی ۴ رقمی را کامل وارد کنید"
            else result.text = names[raw] ?: "کد موردنظر یافت نشد"
            hideKeyboard(code)
        }

        fun updateScoreDescription() {
            val key = scoreCode.text.toString().trim()
            scoreDescription.text = if (key.isBlank()) "—" else scoreDescriptions[key] ?: "کد امتیاز یافت نشد"
        }

        fun updateScorerName() {
            val key = scorerCode.text.toString().trim()
            scorerName.text = if (key.isBlank()) "—" else scorers[key] ?: "کد امتیازدهنده یافت نشد"
        }

        fun clearStudentCodeOnFocus() {
            if (code.hasFocus()) code.text.clear()
        }

        fun clearForm() {
            scoreCode.text.clear()
            scorerCode.text.clear()
            score.text.clear()
            scoreDescription.text = "—"
            scorerName.text = "—"
            code.text.clear()
            result.text = "—"
            code.requestFocus()
        }

        fun registerScore() {
            val studentCode = code.text.toString().filter { it.isDigit() }
            val studentName = names[studentCode]
            val scoreCodeValue = scoreCode.text.toString().trim()
            val scorerCodeValue = scorerCode.text.toString().trim()
            val scoreValue = score.text.toString().trim()
            val descriptionValue = scoreDescriptions[scoreCodeValue]
            val scorerNameValue = scorers[scorerCodeValue]
            if (studentCode.length != 4 || studentName == null) {
                Toast.makeText(this, "ابتدا کد معتبر دانش‌آموز را وارد کنید.", Toast.LENGTH_SHORT).show()
                return
            }
            if (scoreCodeValue.isBlank() || descriptionValue == null || scorerCodeValue.isBlank() || scorerNameValue == null || scoreValue.isBlank()) {
                Toast.makeText(this, "کد امتیاز، کد امتیازدهنده و میزان امتیاز را کامل و معتبر وارد کنید.", Toast.LENGTH_LONG).show()
                return
            }
            val now = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US).format(Date())
            records.add(ScoreRecord(studentCode, studentName, scoreCodeValue, scorerCodeValue, scoreValue, descriptionValue, now))
            saveRecords()
            count.text = "تعداد امتیازهای ثبت‌شده: ${records.size}"
            Toast.makeText(this, "امتیاز با موفقیت ثبت شد.", Toast.LENGTH_SHORT).show()
            clearForm()
        }

        databaseButton.setOnClickListener { chooseInitialData() }
        register.setOnClickListener { registerScore() }
        export.setOnClickListener { confirmAndExportScores() }
        code.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) code.post {
                code.text.clear()
                result.text = "—"
            }
        }
        code.setOnEditorActionListener { _, _, _ -> lookupStudent(); true }
        code.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) { if (s?.length == 4) lookupStudent() }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        scoreCode.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) { updateScoreDescription() }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        scorerCode.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) { updateScorerName() }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })

        bg.addView(TextView(this).apply {
            text = "سامانه داخلی ${getSchoolName()}  •  تولید کننده: علیرضا هامونگرد"
            textSize = 12.5f
            setTextColor(Color.rgb(102, 112, 133))
            gravity = Gravity.CENTER
            setPadding(0, dp(18), 0, 0)
        })
        setContentView(scroll)
    }

    private fun getSchoolName(): String = getSharedPreferences("settings", MODE_PRIVATE)
        .getString("school_name", "دبیرستان دوره اول فرهنگ") ?: "دبیرستان دوره اول فرهنگ"

    private fun changeSchoolName() {
        val input = EditText(this).apply {
            setText(getSchoolName())
            selectAll()
            textSize = 18f
            gravity = Gravity.CENTER
            setSingleLine(true)
        }
        AlertDialog.Builder(this)
            .setTitle("تغییر نام دبیرستان")
            .setMessage("نام جدید دبیرستان را وارد کنید:")
            .setView(input)
            .setNegativeButton("انصراف", null)
            .setPositiveButton("ذخیره") { _, _ ->
                val value = input.text.toString().trim()
                if (value.isNotBlank()) {
                    getSharedPreferences("settings", MODE_PRIVATE).edit().putString("school_name", value).apply()
                    Toast.makeText(this, "نام دبیرستان ذخیره شد. برای نمایش کامل، صفحه دوباره بارگذاری می‌شود.", Toast.LENGTH_SHORT).show()
                    recreate()
                }
            }.show()
    }

    private fun chooseInitialData() {
        val options = arrayOf("کد و نام دانش‌آموزان", "کد و نام امتیازدهندگان", "کد و شرح امتیازات")
        AlertDialog.Builder(this)
            .setTitle("تغذیه اطلاعات اولیه از Excel")
            .setItems(options) { _, which ->
                importKind = which + 1
                val requestCode = when (importKind) { 1 -> PICK_STUDENTS; 2 -> PICK_SCORERS; else -> PICK_SCORES }
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                    putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/octet-stream"))
                }
                startActivityForResult(intent, requestCode)
            }.show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        try {
            val uri = data.data!!
            when (requestCode) {
                PICK_STUDENTS -> {
                    val imported = readTwoColumnExcel(uri)
                    if (imported.isEmpty()) throw IllegalArgumentException()
                    names = imported
                    saveDatabase()
                    Toast.makeText(this, "اطلاعات دانش‌آموزان با موفقیت تغذیه شد: ${names.size} رکورد", Toast.LENGTH_LONG).show()
                }
                PICK_SCORERS -> {
                    val imported = readTwoColumnExcel(uri)
                    if (imported.isEmpty()) throw IllegalArgumentException()
                    scorers = imported
                    saveMap("scorers", scorers)
                    Toast.makeText(this, "اطلاعات امتیازدهندگان با موفقیت تغذیه شد: ${scorers.size} رکورد", Toast.LENGTH_LONG).show()
                }
                PICK_SCORES -> {
                    val imported = readTwoColumnExcel(uri)
                    if (imported.isEmpty()) throw IllegalArgumentException()
                    scoreDescriptions = imported
                    saveMap("scoreDescriptions", scoreDescriptions)
                    Toast.makeText(this, "اطلاعات امتیازات با موفقیت تغذیه شد: ${scoreDescriptions.size} رکورد", Toast.LENGTH_LONG).show()
                }
            }
        } catch (_: Exception) {
            Toast.makeText(this, "خواندن فایل Excel انجام نشد. فایل باید .xlsx و شامل دو ستون کد و شرح/نام باشد.", Toast.LENGTH_LONG).show()
        }
    }

    private fun saveMap(prefName: String, map: Map<String, String>) {
        val raw = map.entries.sortedBy { it.key }.joinToString("\n") {
            Base64.encodeToString(it.key.toByteArray(Charsets.UTF_8), Base64.NO_WRAP) + "|" +
            Base64.encodeToString(it.value.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        }
        getSharedPreferences(prefName, MODE_PRIVATE).edit().putString("rows", raw).apply()
    }

    private fun loadMap(prefName: String): Map<String, String> {
        val raw = getSharedPreferences(prefName, MODE_PRIVATE).getString("rows", "") ?: ""
        if (raw.isBlank()) return emptyMap()
        val result = mutableMapOf<String, String>()
        raw.split("\n").forEach { line ->
            val p = line.split("|", limit = 2)
            if (p.size == 2) try {
                val k = String(Base64.decode(p[0], Base64.NO_WRAP), Charsets.UTF_8)
                val v = String(Base64.decode(p[1], Base64.NO_WRAP), Charsets.UTF_8)
                if (k.isNotBlank() && v.isNotBlank()) result[k] = v
            } catch (_: Exception) {}
        }
        return result
    }

    private fun saveDatabase() = saveMap("students", names)
    private fun loadDatabase() { val loaded = loadMap("students"); if (loaded.isNotEmpty()) names = loaded }

    private fun readTwoColumnExcel(uri: Uri): Map<String, String> {
        val entries = mutableMapOf<String, ByteArray>()
        contentResolver.openInputStream(uri)?.use { input ->
            ZipInputStream(input).use { zis ->
                while (true) {
                    val e = zis.nextEntry ?: break
                    if (!e.isDirectory) entries[e.name] = zis.readBytes()
                    zis.closeEntry()
                }
            }
        } ?: throw IllegalArgumentException("Cannot open file")
        val sharedStrings = entries["xl/sharedStrings.xml"]?.let { parseSharedStrings(it) } ?: emptyList()
        val sheet = entries["xl/worksheets/sheet1.xml"]
            ?: entries.entries.firstOrNull { it.key.startsWith("xl/worksheets/") && it.key.endsWith(".xml") }?.value
            ?: throw IllegalArgumentException("Worksheet not found")
        return parseTwoColumnSheet(sheet, sharedStrings)
    }

    private fun parseSharedStrings(bytes: ByteArray): List<String> {
        val result = mutableListOf<String>()
        val parser = XmlPullParserFactory.newInstance().newPullParser()
        parser.setInput(bytes.inputStream(), "UTF-8")
        var event = parser.eventType
        var insideSi = false
        val text = StringBuilder()
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> if (parser.name == "si") { insideSi = true; text.setLength(0) }
                else if (insideSi && parser.name == "t") text.append(parser.nextText())
                XmlPullParser.END_TAG -> if (parser.name == "si" && insideSi) { result.add(text.toString()); insideSi = false }
            }
            event = parser.next()
        }
        return result
    }

    private fun parseTwoColumnSheet(bytes: ByteArray, sharedStrings: List<String>): Map<String, String> {
        val result = linkedMapOf<String, String>()
        val parser = XmlPullParserFactory.newInstance().newPullParser()
        parser.setInput(bytes.inputStream(), "UTF-8")
        var event = parser.eventType
        var currentRef = ""
        var currentType = ""
        var currentValue = ""
        var currentRow = mutableMapOf<Int, String>()
        var inCell = false
        fun columnIndex(ref: String): Int {
            val letters = ref.takeWhile { it.isLetter() }
            var n = 0
            letters.uppercase(Locale.US).forEach { ch -> n = n * 26 + (ch.code - 'A'.code + 1) }
            return n
        }
        fun finishRow(row: Map<Int, String>) {
            if (row.isEmpty()) return
            val code = row[1]?.trim()?.replace(Regex("\\.0+$"), "") ?: ""
            val value = row[2]?.trim() ?: ""
            val normalized = code.filter { it.isDigit() }
            val header = code.equals("Code", true) || code.equals("کد", true) || code.equals("کد امتیاز", true) || code.equals("کد امتیازدهنده", true)
            if (normalized.isNotBlank() && value.isNotBlank() && !header) result[normalized] = value
        }
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> when (parser.name) {
                    "row" -> currentRow = mutableMapOf()
                    "c" -> { inCell = true; currentRef = parser.getAttributeValue(null, "r") ?: ""; currentType = parser.getAttributeValue(null, "t") ?: ""; currentValue = "" }
                    "v" -> if (inCell) currentValue = parser.nextText()
                    "t" -> if (inCell) currentValue += parser.nextText()
                }
                XmlPullParser.END_TAG -> when (parser.name) {
                    "c" -> {
                        var value = currentValue
                        if (currentType == "s") {
                            val idx = value.toIntOrNull(); value = if (idx != null && idx in sharedStrings.indices) sharedStrings[idx] else ""
                        }
                        currentRow[columnIndex(currentRef)] = value; inCell = false
                    }
                    "row" -> finishRow(currentRow)
                }
            }
            event = parser.next()
        }
        return result
    }

    private fun loadRecords() {
        val raw = getSharedPreferences("scores", MODE_PRIVATE).getString("rows", "") ?: ""
        if (raw.isBlank()) return
        raw.split("\n").forEach { line ->
            val p = line.split("|")
            if (p.size == 7) try {
                val d = p.map { String(Base64.decode(it, Base64.NO_WRAP), Charsets.UTF_8) }
                records.add(ScoreRecord(d[0], d[1], d[2], d[3], d[4], d[5], d[6]))
            } catch (_: Exception) {}
        }
    }

    private fun saveRecords() {
        val raw = records.joinToString("\n") { r ->
            listOf(r.studentCode, r.studentName, r.scoreCode, r.scorerCode, r.score, r.description, r.dateTime)
                .joinToString("|") { Base64.encodeToString(it.toByteArray(Charsets.UTF_8), Base64.NO_WRAP) }
        }
        getSharedPreferences("scores", MODE_PRIVATE).edit().putString("rows", raw).apply()
    }

    private fun confirmAndExportScores() {
        if (records.isEmpty()) {
            Toast.makeText(this, "امتیازی برای دریافت خروجی وجود ندارد.", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("توجه")
            .setMessage("توجه: امتیازات قبلی حذف می‌شوند. آیا از دریافت خروجی اطمینان دارید؟")
            .setNegativeButton("خیر", null)
            .setPositiveButton("بله، دریافت خروجی") { _, _ ->
                if (exportExcel()) {
                    records.clear()
                    saveRecords()
                    Toast.makeText(this, "خروجی با موفقیت دریافت شد و امتیازات قبلی حذف شدند.", Toast.LENGTH_LONG).show()
                    recreate()
                } else {
                    Toast.makeText(this, "دریافت خروجی انجام نشد؛ امتیازات حذف نشدند.", Toast.LENGTH_LONG).show()
                }
            }.show()
    }

    private fun exportExcel(): Boolean {
        return try {
            val bytes = createXlsx()
            val fileName = "Farhang_Scores.xlsx"
            if (Build.VERSION.SDK_INT >= 29) {
                val resolver = contentResolver
                resolver.query(
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    arrayOf(MediaStore.Downloads._ID),
                    "${MediaStore.Downloads.DISPLAY_NAME}=?",
                    arrayOf(fileName),
                    null
                )?.use { c ->
                    while (c.moveToNext()) {
                        resolver.delete(
                            MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                            "${MediaStore.Downloads._ID}=?",
                            arrayOf(c.getLong(0).toString())
                        )
                    }
                }
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                    put(MediaStore.Downloads.MIME_TYPE, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                    put(MediaStore.Downloads.RELATIVE_PATH, "Download/")
                }
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return false
                resolver.openOutputStream(uri)?.use { it.write(bytes) } ?: return false
                lastExportUri = uri
                shareExport(uri)
                true
            } else {
                val file = java.io.File(getExternalFilesDir(null), fileName)
                file.writeBytes(bytes)
                val uri = androidx.core.content.FileProvider.getUriForFile(this, "${packageName}.fileprovider", file)
                lastExportUri = uri
                shareExport(uri)
                true
            }
        } catch (_: Exception) { false }
    }

    private fun shareExport(uri: Uri) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "ارسال فایل اکسل"))
    }

    private fun createXlsx(): ByteArray {
        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { zip ->
            fun entry(name: String, content: String) { zip.putNextEntry(ZipEntry(name)); zip.write(content.toByteArray(Charsets.UTF_8)); zip.closeEntry() }
            entry("[Content_Types].xml", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>""")
            entry("_rels/.rels", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>""")
            entry("xl/workbook.xml", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="امتیازها" sheetId="1" r:id="rId1"/></sheets></workbook>""")
            entry("xl/_rels/workbook.xml.rels", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>""")
            fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")
            fun cell(value: String) = "<c t=\"inlineStr\"><is><t xml:space=\"preserve\">${esc(value)}</t></is></c>"
            val headers = listOf("کد دانش‌آموز", "نام و نام خانوادگی", "کد امتیاز", "شرح امتیاز", "کد امتیازدهنده", "نام امتیازدهنده", "میزان امتیاز", "تاریخ و ساعت")
            val rows = mutableListOf(headers)
            rows.addAll(records.map { r -> listOf(r.studentCode, r.studentName, r.scoreCode, r.description, r.scorerCode, scorers[r.scorerCode] ?: "", r.score, r.dateTime) })
            val sb = StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>")
            rows.forEachIndexed { i, row -> sb.append("<row r=\"").append(i + 1).append("\">"); row.forEach { sb.append(cell(it)) }; sb.append("</row>") }
            sb.append("</sheetData></worksheet>")
            entry("xl/worksheets/sheet1.xml", sb.toString())
        }
        return out.toByteArray()
    }

    private fun hideKeyboard(view: View) {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(view.windowToken, 0)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = radius.toFloat() }
    private fun roundedStroke(fill: Int, stroke: Int, radius: Int) = GradientDrawable().apply { setColor(fill); setStroke(dp(2), stroke); cornerRadius = radius.toFloat() }

    companion object {
        private const val DATA = """7101|آجيلي اميرعباس
7102|آزاد مهدي
7103|آقاجاني فرزاد
7104|احمدي محمدحسن
7105|اسحاقي علي
7106|الزیداوی محمدسجاد
7107|باقري آرتا
7108|بيك محمدي عيني محمدسبحان
7109|پرازده علي رضا
7110|جهاني محمدباقر
7111|حسني بنيامين
7112|رضابيگي ساميار
7113|رضاي رحمتي اميرحسين
7114|زينلي سلمي اميرعلي
7115|سخن گو آروين
7116|شايان نيا اميررضا
7117|شكري پينوندي عليرضا
7118|صادقي نيكو ياسين
7119|صالح محمدامين
7120|طاهري برزكي سيداميرعلي
7121|عبداللهي محمد
7122|عرفاني پور محمدصادق
7123|عليزاده حيوريي علي
7124|قلي زاده محمدپارسا
7125|قيصران اميرعلي
7126|كاشي پور مهيار
7127|لاجوردي زاده سيدپرهام
7128|مرادي محمدسجاد
7129|منصوري نژاد ايليا
7130|مولاوي اميدرضا
7131|ناصري منش علي
7132|نجفي محمدايليا
7133|وحيدمقدم اميد
7201|آشوبي محمدرضا
7202|احمدي محمدماهان
7203|ادهمي محمد
7204|اصفهاني اميرحسام
7205|افشاري اميرعلي
7206|اكبرزاده حميدرضا
7207|اكبري سيدارسلان
7208|اكبري محمدپارسا
7209|الياسي راد آرش
7210|براتی جهرودی محمدمهدی
7211|جمالي رضوي سيدسجاد
7212|چترسحاب محمدمهدي
7213|حاجي ميراحمدي سيدمحمدسالار
7214|خرمي زاده محمدكيان
7215|خزائلي محمدحسام
7216|دهقاني محمدمتين
7217|راه دار محمدرضا
7218|رسولي محمدمتين
7219|رضائي معين آبادي محمدحسين
7220|زاينده رود اميرعلي
7221|ستاره اميرعلي
7222|صابري كوپايي علي
7223|صبوري پرهام
7224|فارسي محمدسبحان
7225|فتح اللهي ايليا
7226|فرخي محمدمعين
7227|فروغي رهقي سيدعلي
7228|محسني كوپائي مجتبي
7229|محمدي سليمي رادين
7230|محمدي فردوئي ميلاد
7231|مسلمي محمدمتين
7232|موحد محمدمجتبي
7233|موسي كاظمي سيدمحمدكسري
7234|نائيني پورحسين آبادي محمدحسين
7235|يزديان كورش
7301|آدمي محمدحسين
7302|بيطرفان سيدمحمدمتين
7303|پيغمبري سيدمحمدكميل
7304|جعفري زگلوجه حسين
7305|جوان حسين
7306|جوان علي اصغر
7307|حاجي رضائي محمدشايان
7308|حيدرزاده محمدصادق
7309|خان اميني سيدمتين
7310|خسروي اميررضا
7311|رضائي محمدسبحان
7312|رياحي مدوار اميرمحمد
7313|رئيس ميرزائي سپهر
7314|سيدمحمدي سيدمحمدمبين
7315|طاهري محمدحسين
7316|عرب بافراني علي
7317|عربي نژاد دانيال
7318|عليخان زاده قمي محمدطه
7319|غفاري اميرحسين
7320|فرجامي ابوالفضل
7321|فروغی سیدعلی
7322|قربان زادگان اميرعلي
7323|كاشغري بيدگلي اميرعلي
7324|كاظمي حسين آباد بنيامين
7325|كاظمي شيخ شباني سيدعلي
7326|گل دوست محمدمعين
7327|محمدي خواه محمد
7328|محمدي فردوئي آرمين
7329|مولوي اميرماهان
7330|مؤمن اميرعباس
7331|ميرزائي محمدمتين
7332|نجم آبادي زاده مهدي
7333|يعقوبلو اميرمحمد
7334|دهقان ابنوی محمدحسین
7401|آيدي حسين
7402|ابراهيمي محمدعرفان
7403|اكبري فرهاد
7404|باقري محمدياسين
7405|ترابي محمدصدرا
7406|تيرناز محمدمهدي
7407|جباري ميلاد
7408|جعفري آراد
7409|حافظ كيا محمدكيان
7410|حسيني سيدطاها
7411|حسيني سيدمحمدصادق
7412|خليلي يزدي سيدمعين
7413|ديداري قره تپه اميرعباس
7414|رجبي اميرعباس
7415|رشيدي پاشا
7416|رضاآبادي اميرعباس
7417|زماني اميرحسين
7418|زينلي اميرعلي
7419|شريعت سيدعلي
7420|شوهانيان محمدصادق
7421|عسكري علي رضا
7422|غفوري ورزنه عماد
7423|غيور سروش
7424|فرهاديان اميرعباس
7425|فريمانهء سينا
7426|كلهر عليرضا
7427|گلبان علي رضا
7428|محمدي نصيري محمدمتين
7429|ملكي مجتبي
7430|موسوي سيدامين
7431|مؤمني محمدعلي
7432|نصيري رضا
7433|نیکوکلام عظیم امیرحافظ
7434|والي علي
7435|والي هاتف
8101|آب يار سيداميرحسين
8102|اردهالي آرمين
8103|اكبري احسان
8104|باقري كيان
8105|بداقي محمداحسان
8106|بدخشان ابراهيم
8107|برزگر مهدي
8108|پوررضا محمدامين
8109|تلخابي سبحان
8110|توحيدي منش علي اصغر
8111|جعفري محمدعلي
8112|حسيني سيدحسين
8113|خلج علي رضا
8114|دادپور محمد
8115|رباني محمدامين
8116|رستمي قمي محمدپارسا
8117|رضازاده عسگري محمدمهدي
8118|رضائي صابر احمدرضا
8119|زارعي محمدمعين
8120|زند محمد
8121|سركشيك سيدمحمد
8122|سيدحسيني زادقم سيدابوالفضل
8123|كاشي پزان قمي اميرمحمد
8124|مرادخاني محمدرضا
8125|مرادي اميرمهدي
8126|مصباحي آزاد محمدميثم
8127|ملا اميرعلي
8128|مهدوي محمدطاها
8129|مولايي راد اميرعباس
8130|ميرزائي محمد
8131|نادري محمدرضا
8132|نصراللهي محمدكيان
8133|ياسان پور محمدماني
8134|يزدان پناه اميرعلي
8135|يزدي محمدصادق
8136|يوسفي محمدعرفان
8137|يوسفي ده نوي محمدمتين
8201|اثني عشري اميرحسين
8202|بشري فرنام
8203|پناهي اميرمحمد
8204|پورفخاري محمدكيان
8205|جانقربان لاريچه علي
8206|جعفرپور محمدمهدي
8207|جهان شاه قمي محمدپرهام
8208|خليف محمدمختار
8209|رجبي ابوالفضل
8210|رحيم دشتي رهام
8211|رضائي اميرعباس
8212|زماني رحمن زاده معين
8213|زند اميرمحمد
8214|زند محمدصدرا
8215|زندي اميرعلي
8216|سيدميرزائي سيدحسن
8217|شاحمزئي علي
8218|شاه ميري اميرعلي
8219|شيخي يزدان
8220|صفري محمدسبحان
8221|عاشوري محمدحسن
8222|عسگري اميرعلي
8223|عقدكي محمدحسن
8224|عليزاده فرد اميرطاها
8225|گلچي سبحان
8226|محمدي علي
8227|محمودي پرهام
8228|مشرفي مقداد
8229|موسوي سيدمحمدامين
8230|موسي كاظمي سيدپارسا
8231|ناظريان فرزين
8232|نجفي فرزانه سبحان
8233|نمازي اصفهاني علي اصغر
8234|وفائي تاجخاتوني فرزين
8235|يوسفي سيدعلي اصغر
8301|افرادي آرمين
8302|بختياري ميلاد
8303|بغدادي علي اصغر
8304|توانا علي
8305|جعفري نژاد اميرارسلان
8306|جعفري نصرآبادي عليرضا
8307|جعفري همت آبادي اميرحسين
8308|جوشقاني كوروش
8309|حسني پاس حامد
8310|حيدري خواه اميرمحمد
8311|حيدرزاده اميرطاها
8312|خراساني اميرعلي
8313|رضائي عليرضا
8314|زرگوش علي
8315|زند اميرعلي
8316|ساجدي پور سعيد
8317|سلامت محمدپرهام
8318|سنائي اميرحافظ
8319|شيخي زاده محمدايليا
8320|شيرزاد ماهان
8321|صالحي محمدعلي
8322|طالعي فرد اميرعلي
8323|طحاني مزرعه نو محمدرضا
8324|عبدالعظيمي مهدي
8325|عربي سپهر
8326|عربي سهيل
8327|قبيله دار اميرعلي
8328|كاشي محمدسامان
8329|كرباسي يزدي محمدامين
8330|كمالي سيدميثم
8331|گودرزي محمدحسين
8332|محمدي محمدپويا
8333|مرادي محمدشايان
8334|مهركش ابوالفضل
8335|موسوي سيدمحمدجواد
8336|نظرزاده علي
9101|اميني ارمكي اميرعلي
9102|بهروزي راد محمدامين
9103|بياتي نعيم مهدي
9104|بيطرفان اميرعلي
9105|پورغلام مجتبي
9106|پيرنظر پارسا
9107|تابان كيان
9108|جليلي دوست اميرعباس
9109|جمشيدي نژاد علي
9110|حدادي گيوي سيدسجاد
9111|حسن پور اميرمهدي
9112|حسینی سیدامیرعباس
9113|خديوي كاشاني علي اصغر
9114|رزي اميرعلي
9115|سعيدي علي
9116|شريعت زاده اميرمحمد
9117|شهبازي پرهام
9118|علي عرب علي
9119|عليزاده حيوريي مهدي
9120|غفوري طاها
9121|غلام مولا محمدحسين
9122|غلامي اميرعباس
9123|فلاحتيان اميرعلي
9124|قمري تيام
9125|لاجوردي محمدطاها
9126|لطفي محمدمهدي
9127|متشكري محمدسپهر
9128|متقي موحد رضا
9129|محمداصفهاني سالار
9130|مرتضوي سيدعلي
9131|مهدوي پور اميرعباس
9132|مؤذني بيستگاني علي
9133|نبوي سيداميرمحمد
9134|نوروزي محمدصالح
9135|هاشميان بيدگلي سيدمتين
9136|ونكي فراهاني اميرعباس
9201|آذري اسفيدواجاني محمدصدرا
9202|آزادبخت محسن
9203|اسحاق سيدمحمدطاها
9204|اسكندري كيان
9205|بدرخاني رضا
9206|بهرامي محمدجواد
9207|جليلي آرش
9208|حسني شورهء متين
9209|خادمي نجف آبادي عليرضا
9210|دهستاني اميرعلي
9211|ذاكري ازناوه سيدعلي
9212|رخسار اميرحسين
9213|رضائي اميرطاها
9214|رضائي قمي محمدحسين
9215|زندي كريم خاني محمد
9216|سعادت عباسي علي
9217|سلامي محمدطه
9218|سيديان سيدشهاب الدين
9219|شاه پسندي علي اكبر
9220|ضياءبروجني اميرحسين
9221|ضيائي نسب محمدسينا
9222|علاقبندي علي اصغر
9223|علوي نژاد سيدمحمدكسرا
9224|علي اكبري علي اصغر
9225|عيوضي اميركوروش
9226|قناتي اميرعباس
9227|لطيفي علي اكبر
9228|محلوجيان اميرعلي
9229|مطهري بيدگلي سيدمحمدسينا
9230|مظفري منفرد محمدعلي
9231|ملاسلماني علي اصغر
9232|نادري نيما
9233|نجفي حامد
9234|نعمتي محمدامين
9235|نويسي پور فؤاد
9301|احمدي پرهام
9302|اركاني بخشايش اميرعباس
9303|اميني ارمكي عباس
9304|بابائي احسان
9305|تبريزي محمدطاها
9306|تلخابي سهيل
9307|جهانگيري پور محمدحسام
9308|جورابچي مهدي
9309|حاجي تقي طهراني اميرمحمد
9310|حسني اميرعباس
9311|حيدري محمدپرهام
9312|خاني پور طاها
9313|خوش لهجه مقدم حامد
9314|درويش عرب محمدپارسا
9315|رستگارمطلق معين
9316|رضائي سروش
9317|رئيس ميرزائي طهراني اميرحافظ
9318|سبحاني سرشت اميررضا
9319|شعرباف پوريا
9320|ظهرابي جمكراني پارسا
9321|عامري فر آرمين
9322|عبداللهي نيستاني محمد
9323|عزيزي محمدمهدي
9324|عليمرداني اميرعباس
9325|غلامي اسفيدواجاني محمدامين
9326|فروزان نژاد اميرحسين
9327|فلاح حسين آبادي حسين
9328|قاسم پور علي
9329|قرباني سهيل
9330|كرماني مطلق اميرحسين
9331|معين مهر ماهان
9332|معيني نميني علي اصغر
9333|نوري محمدحسام
9334|يوسفي ارميا
9401|ابراهيمي محمدمهراد
9402|باقري مطلق رضا
9403|برقي اميرحسين
9404|پورحسن اميرحسين
9405|پورحسيني سيدمحمد
9406|حميدي كلكو محمد
9407|خوشگواري محمدپوريا
9408|رضويان سيدمحمدجواد
9409|رنجبر معين
9410|زارعي سهاميه محمدحسين
9411|شفيعي اميد
9412|شكارچيان محمداحسان
9413|شهركي علي
9414|صابري محمدسبحان
9415|صداقت دوست احسان
9416|طباطبائي كهنگي سيدمصطفي
9417|عسگري محمدصدرا
9418|علويان راد محمدطه
9419|غفاري راد علي اصغر
9420|كاظمي گونلوئي محمدمهدي
9421|كرماني احسان
9422|گنج خانلو پوريا
9423|لاجوردي قم اميررضا
9424|لطفي زاده علي اصغر
9425|مرادي اميرعباس
9426|مطيعي كاشاني علي رضا
9427|ملاحسيني عليرضا
9428|مهدوي يار محمدحسن
9429|ناطق الاسلام محمدپارسا
9430|نجم آبادي زاده اميرحسين
9431|نقدي اميرحسين
9432|نيك خو سينا
9433|وکیل زاده مهدی
9501|اسدالهي متين
9502|تفتي محمدحسين
9503|تكيان آرمين
9504|جعفري زگلوجه اميررضا
9505|جواديان پارسا
9506|حاجي مظفري حسين
9507|خاكبازان مهدي
9508|خراساني اميرعلي
9509|رحيمي سيدعليرضا
9510|رضايي سيدمحمدطاها
9511|زارعي عليرضا
9512|زندي اميررضا
9513|زيدآبادي نژاد اميرمحمد
9514|شعباني نياء علي رضا
9515|شعبانيان اميرحسين
9516|شمس نيا سيداميرعلي
9517|صابري اميرحسين
9518|صابري مهدي
9519|طاهري زاده محمدامين
9520|طاهري زاهد محمدامين
9521|علينقي زاده اميدرضا
9522|فريدي پرهام
9523|قاسمي مهرزاد
9524|كلهري محمدحسين
9525|كوره پزان محمدشايان
9526|كولاري اميرعباس
9527|گرامي قينرجه اميرمهدي
9528|گل بهار اميرعلي
9529|مدبرپور عليرضا
9530|ملا محمدعلي
9531|ممتحن سيدعليرضا
9532|منتظري اميرصدرا
9533|ميرسلطاني سيدمحمدمهدي
9534|نيكبخت اردستاني سيداميرعلي
9535|هاشمي احسان
9536|يزديان علي
9601|آقاجاني علي
9602|آقائي اميرسامان
9603|اكبري جعفرآبادي اميرعلي
9604|ترابي گودرزي حسن
9605|تقي پور حسين
9606|توكلي مقدم بهراد
9607|جوادي فر عليرضا
9608|چهل اختراني سيدحسين
9609|حاج علي گل محمدحسام
9610|حبيبي تبار وحيد
9611|حدادي سيدمحمدطاها
9612|حسيني رهقي سيدمحمدامين
9613|حسيني سيرت سيدحسن
9614|حقگويان محمدمهدي
9615|رحماني علي
9616|رعيت زاده معين
9617|رياحي مدوار مهرداد
9618|زمرديان سيدمتين
9619|زندخانه شهري اميرعباس
9620|زنديه اميرمهدي
9621|سليمانيان بيدگلي اميرعلي
9622|سيدعلي اكبري سيدحسين
9623|سيدمحمدي سيدمحمدمتين
9624|شفيعي اميرمجتبي
9625|صادق محمدعماد
9626|عابديني شهاب
9627|فرضي نژاد دانيال
9628|مراتي حسين
9629|مؤمني دوست حسين
9630|ميرابراهيمي سيداميرحسين
9631|نصراللهي نيرآبادي اميرعباس
9632|نوري نژاد پارسا
9633|واحدي سجاد"""
    }
}
